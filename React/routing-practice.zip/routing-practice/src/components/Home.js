import React from 'react'
import {
    Routes,
    Route,
    Link 
  } from "react-router-dom";

export default function Home() {
  return (
    <div>
            <h1 style={{color: "red"}}>Welcome!</h1>
        </div>
  )
}
